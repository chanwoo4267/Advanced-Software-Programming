// 채팅 키워드 검색창 & 검색 버튼에 대한 컴포넌트 작성
import React, { useState } from "react";
import styled from "styled-components";
import TextField from "@material-ui/core/TextField";
import ChatLogItem from "./ChatLogItem";

// Sending Message 부분
function ChatSearch({ onSearchKeySubmit }) {
  const [SearchState, setSearchState] = useState({ search: ""})

  const onSearchChange = (e) => {
    setSearchState({ ...SearchState, [e.target.name]: e.target.value })
  }

  const onSearchSubmit = (e) => {
      e.preventDefault()
      console.log(SearchState.search);
      onSearchKeySubmit(SearchState.search);
  }

  return (
    <Form onSubmit={onSearchSubmit}>
    <TextField name="search" onChange={onSearchChange} value={SearchState.search} label="search" />
    <Button>Search</Button>
    </Form>
  );
}

const Form = styled.form`
  margin: 10px;
  padding: 20px;
  background-color: #f3eaaf;
`;


const Button = styled.button`
  margin-top: 0px;
  padding: 10px;
  background-color: white;
  border-color: #c8a951;
  border-radius: 5px;
`;

export default ChatSearch;