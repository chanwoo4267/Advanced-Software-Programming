#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>

double bisection2(double* pdfx, double* pdfy, double normal_x, int k, double rnd);
double* bisection_simple(double* pdfx, double* pdfy, double normal_x, int k, double rnd);
double getFx2(double* pdfx, double* pdfy, double normal_x, int n, double to, double rnd);
double secant(double* pdfx, double* pdfy, double normal_x, int k, double rnd);

//����1 - Ex, Vx ��
void program3_1()
{
	srand((unsigned int)time(NULL));
	/* lamda ���� ��ġ */
	double lamda1 = 1.8, lamda2 = 2.7, lamda3 = 3.1;
	int n, i, j;
	double irand;
	double* arr1, * arr2, * arr3;
	double sum[3] = { 0,0,0 };
	double var[3] = { 0,0,0 };

	do {
		printf("Input Random Varialbes count less then 10000 : ");
		scanf("%d", &n);
	} while (n > 10000);
	
	arr1 = (double*)malloc(sizeof(double) * n);
	arr2 = (double*)malloc(sizeof(double) * n);
	arr3 = (double*)malloc(sizeof(double) * n);

	for (i = 0; i < n; i++)
	{
		irand = (double)rand() / (RAND_MAX + 1);
		arr1[i] = (-log(1) + irand) / lamda1;
		arr2[i] = (-log(1) + irand) / lamda2;
		arr3[i] = (-log(1) + irand) / lamda3;

		//printf("%lf %lf %lf\n", arr1[i], arr2[i], arr3[i]);
	}

	for (i = 0; i < n; i++)
	{
		sum[0] += arr1[i];
		sum[1] += arr2[i];
		sum[2] += arr3[i];
	}

	for (i = 0; i < n; i++)
	{
		var[0] += arr1[i] * arr1[i];
		var[1] += arr2[i] * arr2[i];
		var[2] += arr3[i] * arr3[i];
	}

	printf("expected E(x) : %lf\tcalculated E(x) : %lf\n", 1 / lamda1, sum[0] * 2 / n);
	printf("expected E(x) : %lf\tcalculated E(x) : %lf\n", 1 / lamda2, sum[1] * 2 / n);
	printf("expected E(x) : %lf\tcalculated E(x) : %lf\n\n", 1 / lamda3, sum[2] * 2 / n);

	printf("expected V(x) : %lf\tcalculated V(x) : %lf\n", 1 / (lamda1 * lamda1), (var[0] * 6 / n) - (sum[0] * sum[0] * 4) / (n * n));
	printf("expected V(x) : %lf\tcalculated V(x) : %lf\n", 1 / (lamda2 * lamda2), (var[1] * 6 / n) - (sum[1] * sum[1] * 4) / (n * n));
	printf("expected V(x) : %lf\tcalculated V(x) : %lf\n", 1 / (lamda3 * lamda3), (var[2] * 6 / n) - (sum[2] * sum[2] * 4) / (n * n));
}

// histogram ����, Secant ����
void program2_3_secant()
{
	FILE* fp_r, *fp_r2, *fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_r2 = fopen("random_event_table_secant.txt", "r");
	fp_w = fopen("histogram_secant.txt", "w");

	double* pdfx;
	double* pdfy;
	double temp;

	double section[100] = { 0, };
	int sect[100] = { 0, };
	int pdfn, i, randomn, t, j, l;
	double x, k;

	fscanf(fp_r, "%d %lf\n", &pdfn, &x);
	pdfx = (double*)malloc(sizeof(double) * pdfn);
	pdfy = (double*)malloc(sizeof(double) * pdfn);

	for (i = 0; i < pdfn; i++)
		fscanf(fp_r, "%lf %lf\n", &pdfx[i], &pdfy[i]);

	fscanf(fp_r2, "%d\n", &randomn);

	if (randomn >= 10000)
		l = 3;
	else if (randomn >= 1000)
		l = 2;
	else l = 1;

	for (i = 0; i < randomn; i++)
	{
		fscanf(fp_r2, "%lf\n", &temp);
		t = (int)(temp * 100);
		section[t] = temp;
		sect[t]++;
	}

	for (i = 0; i < 100; i++)
		fprintf(fp_w,"%d: %d\n", i, sect[i]);

	// draw random_table image
	fprintf(fp_w,"------------------------------------------------------\n\n");

	for (i = 0; i < 100; i++)
	{
		k = sect[i] / l;
		for (j = 0; j < k; j++)
			fprintf(fp_w, "*");
		fprintf(fp_w,"\n");
	}

	// draw pdf_table image
	fprintf(fp_w, "------------------------------------------------------\n\n");

	for (i = 0; i < pdfn; i++)
	{
		k = pdfy[i] * 100;
		for (j = 0; j < k; j++)
			fprintf(fp_w, "*");
		fprintf(fp_w, "\n");
	}

	if (fp_r != NULL) fclose(fp_r);
	if (fp_r2 != NULL) fclose(fp_r2);
	if (fp_w != NULL) fclose(fp_w);
}

//histogram �����ϴ� �Լ�, Bisection ����
void program2_3()
{
	FILE* fp_r, * fp_r2, * fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_r2 = fopen("random_event_table.txt", "r");
	fp_w = fopen("histogram.txt", "w");

	double* pdfx;
	double* pdfy;
	double temp;

	double section[100] = { 0, };
	int sect[100] = { 0, };
	int pdfn, i, randomn, t, j, l;
	double x, k;

	fscanf(fp_r, "%d %lf\n", &pdfn, &x);
	pdfx = (double*)malloc(sizeof(double) * pdfn);
	pdfy = (double*)malloc(sizeof(double) * pdfn);

	for (i = 0; i < pdfn; i++)
		fscanf(fp_r, "%lf %lf\n", &pdfx[i], &pdfy[i]);

	fscanf(fp_r2, "%d\n", &randomn);

	if (randomn >= 10000)
		l = 3;
	else if (randomn >= 1000)
		l = 2;
	else l = 1;

	for (i = 0; i < randomn; i++)
	{
		fscanf(fp_r2, "%lf\n", &temp);
		t = (int)(temp * 100);
		section[t] = temp;
		sect[t]++;
	}

	for (i = 0; i < 100; i++)
		fprintf(fp_w, "%d: %d\n", i, sect[i]);

	// draw random_table image
	fprintf(fp_w, "------------------------------------------------------\n\n");

	for (i = 0; i < 100; i++)
	{
		k = sect[i] / l;
		for (j = 0; j < k; j++)
			fprintf(fp_w, "*");
		fprintf(fp_w, "\n");
	}

	// draw pdf_table image
	fprintf(fp_w, "------------------------------------------------------\n\n");

	for (i = 0; i < pdfn; i++)
	{
		k = pdfy[i] * 100;
		for (j = 0; j < k; j++)
			fprintf(fp_w, "*");
		fprintf(fp_w, "\n");
	}

	if (fp_r != NULL) fclose(fp_r);
	if (fp_r2 != NULL) fclose(fp_r2);
	if (fp_w != NULL) fclose(fp_w);
}

// Bisection ������� �� ���ϱ�
void program2_2_a()
{
	__int64 start, freq, end;
	float resultTime = 0;

	CHECK_TIME_START;

	// something to do...

	FILE* fp_r, * fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");

	/***************************************************/
	int i = 0;
	int t;
	double irand;
	srand((unsigned int)time(NULL));

	int n;
	double x;
	double* pdfx;
	double* pdfy;
	double result;

	fscanf(fp_r, "%d %lf\n", &n, &x);
	pdfx = (double*)malloc(sizeof(double) * n);
	pdfy = (double*)malloc(sizeof(double) * n);

	for (i = 0; i < n; i++)
		fscanf(fp_r, "%lf %lf\n", &pdfx[i], &pdfy[i]);
	printf("Input n : ");
	scanf("%d", &t);
	fprintf(fp_w, "%d\n", t);
	i = 0;
	while (i < t)
	{
		irand = (double)rand() / (RAND_MAX + 1);
		result = bisection2(pdfx, pdfy, x, n, irand);
		//printf("%.15lf -> %.15lf\n", irand, result);
		fprintf(fp_w, "%.15lf\n", result);
		i++;
	}

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);

	// to do end...

	CHECK_TIME_END(resultTime);

	program2_3();

	printf("The program2_2_a run time is %f(ms)..\n", resultTime * 1000.0);
}

//Secant ������� �� ���ϱ�
void program2_2_b()
{
	__int64 start, freq, end;
	float resultTime = 0;

	CHECK_TIME_START;

	// something to do...
	FILE* fp_r, * fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table_secant.txt", "w");

	/***************************************************/
	int i = 0;
	int t;
	double irand;
	srand((unsigned int)time(NULL));

	int n;
	double x;
	double* pdfx;
	double* pdfy;
	double result;

	fscanf(fp_r, "%d %lf\n", &n, &x);
	pdfx = (double*)malloc(sizeof(double) * n);
	pdfy = (double*)malloc(sizeof(double) * n);

	for (i = 0; i < n; i++)
		fscanf(fp_r, "%lf %lf\n", &pdfx[i], &pdfy[i]);
	printf("Input n : ");
	scanf("%d", &t);
	fprintf(fp_w, "%d\n", t);
	i = 0;
	while (i < t)
	{
		irand = (double)rand() / (RAND_MAX + 1);
		result = secant(pdfx, pdfy, x, n, irand);
		//printf("%.15lf -> %.15lf\n", irand, result);
		fprintf(fp_w, "%.15lf\n", result);
		i++;
	}

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);

	// to do end...

	CHECK_TIME_END(resultTime);

	program2_3_secant();

	printf("The program2_2_b run time is %f(ms)..\n", resultTime * 1000.0);
}

//Ȯ���е� �Լ��� ���ϱ�
double getFx2(double* pdfx, double* pdfy, double normal_x, int n, double x, double rnd)
{
	int i;
	int a = 0;
	double sum1 = 0;

	for (i = 0; i < n; i++)
		if (pdfx[i] <= x && pdfx[i + 1] > x)
			a = i;

	for (i = 1; i < a + 1; i++)
		sum1 += (pdfy[i] + pdfy[i - 1]) * normal_x / 2;

	sum1 += (pdfy[a] + (pdfy[a + 1] - pdfy[a]) / (pdfx[a + 1] - pdfx[a]) * (x - pdfx[a]) / 2) * (x - pdfx[a]);
	return sum1 - rnd;
}

//bisection
double bisection2(double* pdfx, double* pdfy, double normal_x, int k, double rnd)
{
	double a0 = 0.0, b0 = 0.999999, x0, x1, temp = 0;
	int n = 0;
	double r;
	double z;

	while (n < Nmax)
	{
		n++;
		temp = (a0 + b0) / 2;

		r = getFx2(pdfx, pdfy, normal_x, k, temp, rnd);

		if ((fabs(r) < EPSILON) || ((b0 - a0) / 2) < DELTA)
		{
			return temp;
		}

		z = getFx2(pdfx, pdfy, normal_x, k, b0, rnd);


		if (r * z < 0) 
			a0 = temp;
		else 
			b0 = temp;
	}
	return temp;
}

//secant ��Ŀ��� �ʱⰪ ������ ���� bisection
double* bisection_simple(double* pdfx, double* pdfy, double normal_x, int k, double rnd)
{
	double a0 = 0.0, b0 = 0.999999, x0, x1, temp = 0;
	int n = 0;
	double r;
	double z;
	double t[2];

	while (n < 10)
	{
		n++;
		temp = (a0 + b0) / 2;

		r = getFx2(pdfx, pdfy, normal_x, k, temp, rnd);

		if ((fabs(r) < EPSILON) || ((b0 - a0) / 2) < DELTA)
		{
			t[0] = a0;
			t[1] = b0;
			return t;
		}

		z = getFx2(pdfx, pdfy, normal_x, k, b0, rnd);


		if (r * z < 0)
			a0 = temp;
		else
			b0 = temp;
	}

	t[0] = a0;
	t[1] = b0;
	return t;
}

//secant
double secant(double* pdfx, double* pdfy, double normal_x, int k, double rnd)
{
	int n=0;

	double r=0;
	double z=0;

	double mid_value;
	double next_value;
	double prev_value;
	//double t[2];

	double* t = bisection_simple(pdfx, pdfy, normal_x, k, rnd);
	//t[1] = 0.999999;
	//t[0] = 0.0;

	mid_value = t[1];
	prev_value = t[0];

	r = getFx2(pdfx, pdfy, normal_x, k, mid_value, rnd);
	z = getFx2(pdfx, pdfy, normal_x, k, prev_value, rnd);

	next_value = mid_value - r * ((mid_value - prev_value) / (r - z));

	while (1)
	{
		//end check
		if (fabs(next_value) < EPSILON)
			break;
		if (n >= Nmax)
			break;
		if (fabs(next_value - mid_value) < DELTA)
			break;

		prev_value = mid_value;
		mid_value = next_value;
		next_value = mid_value - r * ((mid_value - prev_value) / (r - z));
		n++;
	}
	//printf("result is %.15e\n", mid_value);
	return mid_value;
}
