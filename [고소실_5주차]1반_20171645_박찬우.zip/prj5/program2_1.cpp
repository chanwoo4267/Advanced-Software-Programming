#include "my_solver.h"

void program2_1()
{
	FILE* fp_r, *fp_w;
	__int64 start, freq, end;
	float resultTime = 0;

	fp_r = fopen("sampling_table.txt", "r");
	if (fp_r == NULL) {
		printf("input file not found....\n");
		exit(0);
	}

	fp_w = fopen("pdf_table.txt", "w");

	/***************************************************/
	int n;
	double x;
	double* arrx;
	double* arry;
	double* pdfx;
	double* pdfy;
	double sum = 0;
	double printtemp = 0;
	int i;
	double normal_x;
	double sum1 = 0;
	double sum2 = 0;
	double sum3 = 0;
	int a, b, c;

	fscanf(fp_r, "%d %lf\n", &n, &x);


	arrx = (double*)malloc(sizeof(double) * n);
	arry = (double*)malloc(sizeof(double) * n);
	pdfx = (double*)malloc(sizeof(double) * n);
	pdfy = (double*)malloc(sizeof(double) * n);

	for (i = 0; i < n; i++)
		fscanf(fp_r, "%lf %lf\n", &arrx[i], &arry[i]);

	// make pdf table
	// x normalize
	for (i = 0; i < n; i++)
		pdfx[i] = 1.0 / (n-1) * i;

	normal_x = 1.0 / (n - 1);

	// y normalize
	for (i = 0; i < n; i++)
		sum += arry[i];
	for (i = 1; i < n - 1; i++)
		sum += arry[i];

	double t = sum * normal_x / 2;

	for (i = 0; i < n; i++)
		pdfy[i] = arry[i] / t;

	fprintf(fp_w, "%d %lf\n", n, normal_x);
	for (i = 0; i < n; i++)
		fprintf(fp_w, "%lf %lf\n", pdfx[i], pdfy[i]);

	sum = 0;
	for (i = 1; i < n; i++)
		sum += (pdfy[i] + pdfy[i - 1]) * normal_x / 2;
	printf("*** Intergrating the pdf from 0 to 1 : %lf\n", sum);

	//print
	for (i = 0; i < n; i++)
		if (pdfx[i] <= 0.25 && pdfx[i + 1] > 0.25)
			a = i;
	for (i = 0; i < n; i++)
		if (pdfx[i] <= 0.5 && pdfx[i + 1] > 0.5)
			b = i;
	for (i = 0; i < n; i++)
		if (pdfx[i] <= 0.75 && pdfx[i + 1] > 0.75)
			c = i;

	for(i=1; i<a+1; i++)
		sum1 += (pdfy[i] + pdfy[i - 1]) * normal_x / 2;
	sum1 += (pdfy[a] + (pdfy[a+1] - pdfy[a]) / (pdfx[a+1] - pdfx[a]) * (0.25 - pdfx[a]) / 2) * (0.25 - pdfx[a]);
	printf("*** Intergrating the pdf from 0 to 0.25 : %lf\n", sum1);

	for (i = 1; i < b + 1; i++)
		sum2 += (pdfy[i] + pdfy[i - 1]) * normal_x / 2;
	sum2 += (pdfy[b] + (pdfy[b + 1] - pdfy[b]) / (pdfx[b + 1] - pdfx[b]) * (0.5 - pdfx[b]) / 2) * (0.5 - pdfx[b]);
	printf("*** Intergrating the pdf from 0.25 to 0.5 : %lf\n", sum2 - sum1);

	for (i = 1; i < c + 1; i++)
		sum3 += (pdfy[i] + pdfy[i - 1]) * normal_x / 2;
	sum3 += (pdfy[c] + (pdfy[c + 1] - pdfy[c]) / (pdfx[c + 1] - pdfx[c]) * (0.75 - pdfx[c]) / 2) * (0.75 - pdfx[c]);
	printf("*** Intergrating the pdf from 0.5 to 0.75 : %lf\n", sum3 - sum2);
	printf("*** Intergrating the pdf from 0.75 to 1.0 : %lf\n", sum - sum3);
	/***************************************************/

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}
