﻿#include "my_solver.h"

int main() {
    program2_1(); // make pdf table
    program2_2(); // create random number

    //숙제1 - Ex, Vx 이론값과 계산값 비교
    program3_1(); // HOMEWORK

    //숙제2 - Bisection과 Secant의 실행시간 차이 비교 및 histogram구축
    program2_2_a();
    program2_2_b();
}
