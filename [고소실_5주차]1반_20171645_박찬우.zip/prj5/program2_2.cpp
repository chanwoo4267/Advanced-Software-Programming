#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <random>

double bisection(double* pdfx, double* pdfy, double normal_x, int k, double rnd);
double getFx(double* pdfx, double* pdfy, double normal_x, int n, double to, double rnd);

#define ERROR 0.000000000001

void program2_2()
{
	FILE* fp_r, *fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");

	/***************************************************/
	int i = 0;
	int t;
	double irand;
	srand((unsigned int)time(NULL));
	
	int n;
	double x;
	double* pdfx;
	double* pdfy;
	double result;

	fscanf(fp_r, "%d %lf\n", &n, &x);
	pdfx = (double*)malloc(sizeof(double) * n);
	pdfy = (double*)malloc(sizeof(double) * n);

	for (i = 0; i < n; i++)
		fscanf(fp_r, "%lf %lf\n", &pdfx[i], &pdfy[i]);

	/*test
	printf("%.15lf -> %.15lf\n", 0.05, bisection(pdfx, pdfy, x, n, 0.05));
	printf("%.15lf -> %.15lf\n", 0.15, bisection(pdfx, pdfy, x, n, 0.15));
	printf("%.15lf -> %.15lf\n", 0.25, bisection(pdfx, pdfy, x, n, 0.25));
	printf("%.15lf -> %.15lf\n", 0.35, bisection(pdfx, pdfy, x, n, 0.35));
	printf("%.15lf -> %.15lf\n", 0.45, bisection(pdfx, pdfy, x, n, 0.45));
	printf("%.15lf -> %.15lf\n", 0.55, bisection(pdfx, pdfy, x, n, 0.55));
	printf("%.15lf -> %.15lf\n", 0.65, bisection(pdfx, pdfy, x, n, 0.65));
	printf("%.15lf -> %.15lf\n", 0.75, bisection(pdfx, pdfy, x, n, 0.75));
	printf("%.15lf -> %.15lf\n", 0.85, bisection(pdfx, pdfy, x, n, 0.85));
	printf("%.15lf -> %.15lf\n", 0.95, bisection(pdfx, pdfy, x, n, 0.95));
��밪 �л� ����
	printf("%lf %lf\n", 0.05, getFx(pdfx, pdfy, x, n, 0.05, 0));
	printf("%lf %lf\n", 0.15, getFx(pdfx, pdfy, x, n, 0.15, 0));
	printf("%lf %lf\n", 0.25, getFx(pdfx, pdfy, x, n, 0.25, 0));
	printf("%lf %lf\n", 0.35, getFx(pdfx, pdfy, x, n, 0.35, 0));
	printf("%lf %lf\n", 0.45, getFx(pdfx, pdfy, x, n, 0.45, 0));
	printf("%lf %lf\n", 0.55, getFx(pdfx, pdfy, x, n, 0.55, 0));
	printf("%lf %lf\n", 0.65, getFx(pdfx, pdfy, x, n, 0.65, 0));
	printf("%lf %lf\n", 0.75, getFx(pdfx, pdfy, x, n, 0.75, 0));
	printf("%lf %lf\n", 0.85, getFx(pdfx, pdfy, x, n, 0.85, 0));
	printf("%lf %lf\n", 0.95, getFx(pdfx, pdfy, x, n, 0.95, 0)); */

	printf("Input n : ");
	scanf("%d", &t);
	fprintf(fp_w, "%d\n", t);
	i = 0;
	while (i < t)
	{
		irand = (double)rand() / (RAND_MAX + 1);
		result = bisection(pdfx, pdfy, x, n, irand);
		printf("%.15lf -> %.15lf\n", irand, result);
		fprintf(fp_w, "%.15lf\n", result);
		i++;
	}
	/***************************************************/

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}

double getFx(double* pdfx, double* pdfy, double normal_x, int n, double x, double rnd)
{
	int i;
	int a=0;
	double sum1 = 0;

	for (i = 0; i < n; i++)
		if (pdfx[i] <= x && pdfx[i + 1] > x)
			a = i;

	for (i = 1; i < a + 1; i++)
		sum1 += (pdfy[i] + pdfy[i - 1]) * normal_x / 2;

	sum1 += (pdfy[a] + (pdfy[a + 1] - pdfy[a]) / (pdfx[a + 1] - pdfx[a]) * (x - pdfx[a]) / 2) * (x - pdfx[a]);
	return sum1 - rnd;
}

double bisection(double* pdfx, double* pdfy, double normal_x, int k, double rnd)
{
	double a0 = 0.0, b0 = 0.999, x0, x1, temp = 0;
	int n = 0;
	double r;
	double z;

	while (n < Nmax)
	{
		n++;
		temp = (a0 + b0) / 2;

		r = getFx(pdfx, pdfy, normal_x, k, temp, rnd);

		if ((fabs(r) < EPSILON) || ((b0 - a0) / 2) < DELTA)
		{
			//printf("%d\t%.15e\t\t%.15e\n", n, temp, fabs(r));
			//printf("result is %.15e\n", temp);
			return temp;
		}

		//printf("%lf %lf %d\t%.15e\t\t%.15e\t", a0, b0, n, temp, fabs(r));

		z = getFx(pdfx, pdfy, normal_x, k, b0, rnd);

		//printf("%lf %lf\n", r, z);

		
		if (r * z < 0) {
			a0 = temp;
		}
		else {
			b0 = temp;
		}

	}

	return temp;
}
