#include "my_solver.h"

extern float (*_sp_f)(float);
extern float (*_sp_fp)(float);

/*********************************************
  Newton-Rapson Method
**********************************************/
void sp_program1_1(FILE* fp) {
	int n;
	float initial_value;
	float next_value;

	if (fp == NULL)
		return;

	printf("Input initial value : ");
	scanf("%f", &initial_value);

	n = 0;
	fprintf(fp, "n\t\txn1\t\t\t|f(xn1)|\n");
	fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, initial_value, fabs(_sp_f(initial_value)));

	next_value = initial_value - (_sp_f(initial_value) / _sp_fp(initial_value));
	n++;

	while (1)
	{
		//end check
		if (fabs(next_value) < EPSILON)
			break;
		if (n >= Nmax)
			break;
		if (fabs(next_value - initial_value) < DELTA)
			break;

		fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, next_value, fabs(_sp_f(next_value)));
		initial_value = next_value;
		next_value = initial_value - (_sp_f(initial_value) / _sp_fp(initial_value));
		n++;
	}

	printf("result is %.15e\n", initial_value);
}
