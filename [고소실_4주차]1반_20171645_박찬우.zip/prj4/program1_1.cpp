#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Newton-Rapson Method
**********************************************/
void program1_1(FILE* fp) {
	int n;
	double initial_value;
	double next_value;

	if (fp == NULL)
		return;

	printf("Input initial value : ");
	scanf("%lf", &initial_value);

	n = 0;
	fprintf(fp, "n\t\txn1\t\t\t|f(xn1)|\n");
	fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, initial_value, fabs(_f(initial_value)));
	
	next_value = initial_value - (_f(initial_value) / _fp(initial_value));
	n++;

	while (1)
	{
		//end check
		if (fabs(next_value) < EPSILON)
			break;
		if (n >= Nmax)
			break;
		if (fabs(next_value - initial_value) < DELTA)
			break;

		fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, next_value, fabs(_f(next_value)));
		initial_value = next_value;
		next_value = initial_value - (_f(initial_value) / _fp(initial_value));
		n++;
	}

	printf("result is %.15e\n", initial_value);
}
