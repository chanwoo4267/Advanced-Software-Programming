#include "my_solver.h"

extern float (*_sp_f)(float);
extern float (*_sp_fp)(float);

/*********************************************
  Secant Method
**********************************************/
void sp_program1_2(FILE* fp) {
	int n;

	float mid_value;
	float next_value;
	float prev_value;

	if (fp == NULL)
		return;

	printf("Input x1 : ");
	scanf("%f", &mid_value);
	printf("Input x0 : ");
	scanf("%f", &prev_value);

	n = 0;
	fprintf(fp, "n\t\txn1\t\t\t|f(xn1)|\n");
	fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, prev_value, fabs(_sp_f(prev_value)));
	n++;
	fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, mid_value, fabs(_sp_f(mid_value)));

	next_value = mid_value - _sp_f(mid_value) * ((mid_value - prev_value) / (_sp_f(mid_value) - _sp_f(prev_value)));
	n++;

	while (1)
	{
		//end check
		if (fabs(next_value) < EPSILON)
			break;
		if (n >= Nmax)
			break;
		if (fabs(next_value - mid_value) < DELTA)
			break;

		fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, next_value, fabs(_sp_f(next_value)));
		prev_value = mid_value;
		mid_value = next_value;
		next_value = mid_value - _sp_f(mid_value) * ((mid_value - prev_value) / (_sp_f(mid_value) - _sp_f(prev_value)));
		n++;
	}

	printf("result is %.15e\n", mid_value);
}
