#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Secant Method
**********************************************/
void program1_2(FILE* fp) {
	int n;

	double mid_value;
	double next_value;
	double prev_value;

	if (fp == NULL)
		return;

	printf("Input x1 : ");
	scanf("%lf", &mid_value);
	printf("Input x0 : ");
	scanf("%lf", &prev_value);

	n = 0;
	fprintf(fp, "n\t\txn1\t\t\t|f(xn1)|\n");
	fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, prev_value, fabs(_f(prev_value)));
	n++;
	fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, mid_value, fabs(_f(mid_value)));

	next_value = mid_value - _f(mid_value) * ((mid_value - prev_value) / (_f(mid_value) - _f(prev_value)));
	n++;

	while (1)
	{
		//end check
		if (fabs(next_value) < EPSILON)
			break;
		if (n >= Nmax)
			break;
		if (fabs(next_value - mid_value) < DELTA)
			break;

		fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, next_value, fabs(_f(next_value)));
		prev_value = mid_value;
		mid_value = next_value;
		next_value = mid_value - _f(mid_value) * ((mid_value - prev_value) / (_f(mid_value) - _f(prev_value)));
		n++;
	}
	printf("result is %.15e\n", mid_value);
}
