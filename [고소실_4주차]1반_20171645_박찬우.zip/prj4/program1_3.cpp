#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Bisection Method -- HOMEWORK
**********************************************/
void program1_3(FILE *fp)
{
	double a0=0, b0=0, x0, x1 , temp;
	int n = 0;
	printf("Input a, b : ");
	scanf("%lf %lf", &a0, &b0);

	fprintf(fp, "n\t\txn1\t\t\t|f(xn1)|\n");
	fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, a0, fabs(_f(a0)));
	n++;
	fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, b0, fabs(_f(b0)));

	while (n < Nmax)
	{
		n++;
		temp = (a0 + b0) / 2;

		if ((fabs(_f(temp)) < EPSILON) || ((b0 - a0) / 2) < DELTA)
		{
			fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, temp, fabs(_f(temp)));
			printf("result is %.15e\n", temp);
			return;
		}

		fprintf(fp, "%d\t%.15e\t\t%.15e\n", n, temp, fabs(_f(temp)));

		if (_f(b0) * _f(temp) < 0)
			a0 = temp;
		else
			b0 = temp;
	}
}