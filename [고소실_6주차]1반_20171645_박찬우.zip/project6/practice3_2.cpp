#include "my_solver.h"

void pow(double x_r, double x_i, int degree, double* t_r, double* t_i)
{
	*t_r = x_r;
	*t_i = x_i;

	for (int i = 0; i < degree-1; i++)
	{
		double temp = *t_r;
		*t_r = (*t_r) * x_r - (*t_i) * x_i;
		*t_i = (temp) * x_i + x_r * (*t_i);
	}
}


void practice3_2() {
	char readfile[256];
	char writefile[256];

	int NCOEF, DEGREE;

	double* poly;
	double* zeror, * zeroi;
	double* res;
	long int fail;
	int i;
	int j;

	for (int t = 1; t <= 6; t++) {

		sprintf(readfile, "polynomial_3-2_%d.txt", t);
		sprintf(writefile, "roots_3-2_%d.txt", t);

		FILE* fp_r = fopen(readfile, "r");
		if (fp_r == NULL) {
			printf("%s file open error...\n", readfile);
			return;
		}

		FILE* fp_w = fopen(writefile, "w");
		if (fp_w == NULL) {
			printf("%s file open error...\n", writefile);
			return;
		}

		fscanf(fp_r, "%d", &DEGREE);
		NCOEF = DEGREE + 1;

		poly = (double*)malloc(sizeof(double) * NCOEF);
		zeror = (double*)malloc(sizeof(double) * DEGREE);
		zeroi = (double*)malloc(sizeof(double) * DEGREE);
		res = (double*)malloc(sizeof(double) * DEGREE);

		/********************************/

		for (i = 0; i < NCOEF; i++)
			fscanf(fp_r, "%lf", &poly[i]);

		rpoly_(poly, &DEGREE, zeror, zeroi, &fail);
		if (fail) {
			fprintf(fp_w,"fail\n");
		}

		//���Ȯ��
		for (int k = 0; k < DEGREE; k++)
		{
			double x_r = zeror[k];
			double x_i = zeroi[k];
			fprintf(fp_w,"X%d = %10f + %10fi | ", k + 1, x_r, x_i);

			double result_r = 0;
			double result_i = 0;
			for (i = 0; i < DEGREE; i++)
			{
				double temp_r;
				double temp_i;
				pow(x_r, x_i, DEGREE - i, &temp_r, &temp_i);
				result_r += temp_r * poly[i];
				result_i += temp_i * poly[i];
			}
			result_r += poly[DEGREE];
			fprintf(fp_w,"result = %10f\n", sqrt(result_r * result_r + result_i * result_i));
		}
		fprintf(fp_w,"\n");

		/********************************/


		free(zeroi);
		free(zeror);
		free(poly);

		if (fp_r != NULL) fclose(fp_r);
		if (fp_w != NULL) fclose(fp_w);
	}
}