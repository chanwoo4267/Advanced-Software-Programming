#include "my_solver.h"

#define SOLNUMS 3
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001

void fcn3_5(int* n, double* x, double* fvec, int* iflag)
{
	/********************************/

	fvec[0] = 10 * x[0] - 2.0 * x[1] * x[1] + x[1] - 2.0 * x[2] - 5.0;
	fvec[1] = 8.0 * x[1] * x[1] + 4.0 * x[2] * x[2] - 9.0;
	fvec[2] = 8.0 * x[1] * x[2] + 4.0;

	/********************************/
}

void practice3_5(void)
{
	int n = SOLNUMS;
	double x0[SOLNUMS] = { 1.0, -1.0, 1.0 };	//need to initilize x0
	double x1[SOLNUMS] = { 1.0, 1.0, -1.0 };
	double fvec[SOLNUMS];
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (3 * SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (3 * SOLNUMS + 13)) / 2;

	FILE* fp_w = fopen("roots_3-5.txt", "w");
	if (fp_w == NULL) {
		printf("%s file open error...\n", "roots_3-5.txt");
		return;
	}

	/********************************/

	hybrd1_(fcn3_5, &n, x0, fvec, &tol, &info, wa, &lwa);
	fprintf(fp_w, "initial value : %lf %lf %lf\n", 1.0, -1.0, 1.0);
	fprintf(fp_w, "result value : %lf %lf %lf\n", x0[0], x0[1], x0[2]);
	fprintf(fp_w, "diff : %lf %lf %lf\n", fvec[0], fvec[1], fvec[2]);

	fprintf(fp_w, "\n\n");

	hybrd1_(fcn3_5, &n, x1, fvec, &tol, &info, wa, &lwa);
	fprintf(fp_w, "initial value : %lf %lf %lf\n", 1.0, 1.0, -1.0);
	fprintf(fp_w, "result value : %lf %lf %lf\n", x1[0], x1[1], x1[2]);
	fprintf(fp_w, "diff : %lf %lf %lf\n", fvec[0], fvec[1], fvec[2]);

	/********************************/

	fclose(fp_w);
}