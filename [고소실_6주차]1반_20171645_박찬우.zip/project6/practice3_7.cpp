#include "my_solver.h"

#define SOLNUMS 2
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001

void fcn3_7(int* n, double* x, double* fvec, int* iflag)
{
	/********************************/

	fvec[0] = 2.0 * x[0] * x[0] * x[0] - 12.0 * x[0] - x[1] - 1.0;
	fvec[1] = -x[0] + 3.0 * x[1] * x[1] - 6.0 * x[1] - 3.0;

	/********************************/
}

void practice3_7(void)
{
	int n = SOLNUMS;
	double x0[SOLNUMS] = { -4.0, 5.0 };	//need to initilize x0
	double x1[SOLNUMS] = { -4.0, -5.0 };
	double x2[SOLNUMS] = { 4.0, 5.0 };
	double x3[SOLNUMS] = { 4.0, -5.0 };
	double x4[SOLNUMS] = { 0, 1.0 };
	double x5[SOLNUMS] = { 0, 0.0 };

	double fvec[SOLNUMS];
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (3 * SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (3 * SOLNUMS + 13)) / 2;

	FILE* fp_w = fopen("roots_3-7.txt", "w");
	if (fp_w == NULL) {
		printf("%s file open error...\n", "roots_3-7.txt");
		return;
	}

	/********************************/

	hybrd1_(fcn3_7, &n, x0, fvec, &tol, &info, wa, &lwa);
	fprintf(fp_w, "result value : %lf %lf\n", x0[0], x0[1]);
	fprintf(fp_w, "diff : %lf %lf\n", fvec[0], fvec[1]);

	fprintf(fp_w, "\n\n");

	hybrd1_(fcn3_7, &n, x1, fvec, &tol, &info, wa, &lwa);
	fprintf(fp_w, "result value : %lf %lf\n", x1[0], x1[1]);
	fprintf(fp_w, "diff : %lf %lf\n", fvec[0], fvec[1]);

	fprintf(fp_w, "\n\n");

	hybrd1_(fcn3_7, &n, x2, fvec, &tol, &info, wa, &lwa);
	fprintf(fp_w, "result value : %lf %lf\n", x2[0], x2[1]);
	fprintf(fp_w, "diff : %lf %lf\n", fvec[0], fvec[1]);

	fprintf(fp_w, "\n\n");

	hybrd1_(fcn3_7, &n, x3, fvec, &tol, &info, wa, &lwa);
	fprintf(fp_w, "result value : %lf %lf\n", x3[0], x3[1]);
	fprintf(fp_w, "diff : %lf %lf\n", fvec[0], fvec[1]);

	fprintf(fp_w, "\n\n");

	hybrd1_(fcn3_7, &n, x4, fvec, &tol, &info, wa, &lwa);
	fprintf(fp_w, "result value : %lf %lf\n", x4[0], x4[1]);
	fprintf(fp_w, "diff : %lf %lf\n", fvec[0], fvec[1]);

	fprintf(fp_w, "\n\n");

	hybrd1_(fcn3_7, &n, x5, fvec, &tol, &info, wa, &lwa);
	fprintf(fp_w, "result value : %lf %lf\n", x5[0], x5[1]);
	fprintf(fp_w, "diff : %lf %lf\n", fvec[0], fvec[1]);

	/********************************/

	fclose(fp_w);
}