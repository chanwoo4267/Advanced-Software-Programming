#include "my_solver.h"

#define index_2d(row, col, dim) row*dim+col

void program3_4()
{
	float* a;
	float* aa;
	float* b;
	float* bb;
	float* s;
	float* x;
	int* l;
	int n;
	int i,j,ia;

	float up = 0;
	float down = 0;
	float t = 0;

	FILE* fp_r = fopen("linear_system_3-4.txt", "r");
	if (fp_r == NULL) {
		printf("%s file open error...\n", "linser_system_3-4.txt");
		return;
	}

	FILE* fp_w = fopen("solution_3-4.txt", "w");
	if (fp_w == NULL) {
		printf("%s file open error...\n", "solution_3-4.txt");
		return;
	}

	fscanf(fp_r, "%d\n", &n);
	if (n > 32)
	{
		printf("Input N is larger than 32, so exit\n");
		fclose(fp_r);
		fclose(fp_w);
	}

	a = (float*)malloc(sizeof(float) * n * n);
	aa = (float*)malloc(sizeof(float) * n * n);
	b = (float*)malloc(sizeof(float) * n);
	bb = (float*)malloc(sizeof(float) * n);
	s = (float*)malloc(sizeof(float) * n);
	x = (float*)malloc(sizeof(float) * n);
	l = (int*)malloc(sizeof(int) * n);
	ia = n;

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++)
		{
			fscanf(fp_r, "%f\n", &t);
			a[index_2d(i, j, n)] = t;
			aa[index_2d(i, j, n)] = t;
		}
	}

	for (i = 0; i < n; i++)
	{
		for (j = i; j < n; j++)
		{
			t = a[index_2d(i, j, n)];
			a[index_2d(i, j, n)] = a[index_2d(j, i, n)];
			a[index_2d(j, i, n)] = t;
		}
	}

	for (i = 0; i < n; i++) {
		fscanf(fp_r, "%f\n", &b[i]);
		bb[i] = b[i];
	}

	gespp_(&n, a, &ia, l, s);
	solve_(&n, a, &ia, l, b, x);

	fprintf(fp_w, "%d\n", n);
	for (i = 0; i < n; i++)
		fprintf(fp_w, "%f\n", x[i]);

	for (i = 0; i < n; i++)
	{
		down += bb[i] * bb[i];
		t = 0;
		for (j = 0; j < n; j++)
		{
			t += aa[i * n + j] * x[j];
		}
		t = t - bb[i];
		up += t * t;
	}
	down = sqrt(down);
	up = sqrt(up);

	fprintf(fp_w,"%.6lf\n", up / down);

	fclose(fp_r);
	fclose(fp_w);

	return;
}